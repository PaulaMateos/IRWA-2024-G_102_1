import os
from json import JSONEncoder

# pip install httpagentparser
import httpagentparser  # for getting the user agent as json
import nltk
from flask import Flask, render_template, session, request, redirect, url_for
from myapp.analytics.analytics_data import AnalyticsData, ClickedDoc
from myapp.search.load_corpus  import load_corpus
from myapp.search.objects import Document, StatsDocument
from myapp.search.search_engine import SearchEngine

from user_agents import parse
from geoip2.database import Reader
from datetime import datetime, timezone

from flask_sqlalchemy import SQLAlchemy
from myapp.data_model.models import db

# *** for using method to_json in objects ***
def _default(self, obj):
    return getattr(obj.__class__, "to_json", _default.default)(obj)

_default.default = JSONEncoder().default
JSONEncoder.default = _default

# instantiate the Flask application
app = Flask(__name__)

# Configure the database URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///analytics.db'  # SQLite database file
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable track modifications warning

# Initialize the database
db.init_app(app)

# Create the database and tables
with app.app_context():
    db.create_all()


# random 'secret_key' is used for persisting data in secure cookie
app.secret_key = 'afgsreg86sr897b6st8b76va8er76fcs6g8d7'
app.session_cookie_name = 'IRWA_SEARCH_ENGINE'

# instantiate our search engine
search_engine = SearchEngine()

# instantiate our in memory persistence
analytics_data = AnalyticsData()

# load corpus into memory
full_path = os.path.realpath(__file__)
path, filename = os.path.split(full_path)
file_path = path + "/farmers-protest-tweets.json"
corpus = load_corpus(file_path)
print("loaded corpus. first elem:", list(corpus.values())[0])


import requests
import random

# Sample list of cities and countries for random assignment
locations = [
    ("New York", "USA"),
    ("London", "UK"),
    ("Tokyo", "Japan"),
    ("Paris", "France"),
    ("Berlin", "Germany"),
    ("Sydney", "Australia"),
    ("Mumbai", "India"),
    ("Toronto", "Canada"),
    ("Cape Town", "South Africa"),
    ("Rio de Janeiro", "Brazil")
]

# Randomly assign a location for each search (since real info cannot obtained due to local IPs)
def assign_random_location():
    city, country = random.choice(locations)
    return city, country


def get_geolocation(ip_address):
    """Get geolocation data using ipinfo.io with fallback for local IPs."""
    try:
        # Handle private/local IPs
        if ip_address.startswith('127.') or ip_address.startswith('192.168.') or ip_address.startswith('10.'):
            city, country = assign_random_location()
            return city, country #"Localhost", "Local Network"

        # Use ipinfo.io API
        api_url = f'https://ipinfo.io/{ip_address}/json?token=25a547774a1735' # token=... used from ipinfo.io
        response = requests.get(api_url)
        if response.status_code == 200:
            data = response.json()
            city = data.get("city", "Unknown")
            country = data.get("country", "Unknown")
            return city, country
        else:
            print(f"ipinfo.io API error: {response.status_code}")
            return "Unknown", "Unknown"
    except Exception as e:
        print(f"Geolocation API error: {e}")
        return "Unknown", "Unknown"


@app.route('/')
def index():
    print("starting home url /...")

    # flask server creates a session by persisting a cookie in the user's browser.
    # the 'session' object keeps data between multiple requests
    session['some_var'] = "IRWA 2021 home"

    # Capture user details
    user_agent = request.headers.get('User-Agent')
    print("Raw user browser:", user_agent)
    
    user_ip = request.remote_addr  # This gives the IP address of the user
    agent = httpagentparser.detect(user_agent)
    print("Remote IP: {} - JSON user browser {}".format(user_ip, agent))
    
    session_id = session.get('session_id', str(datetime.now().timestamp()))
    session['session_id'] = session_id
    # Get geolocation data
    city, country = get_geolocation(user_ip)

    # Parse user-agent details
    parsed_agent = parse(user_agent)
    browser = parsed_agent.browser.family 
    os = parsed_agent.os.family
    device_type = "Mobile" if parsed_agent.is_mobile else "Desktop"

    # Get time of day and date
    visit_time = datetime.now().strftime("%H:%M:%S")
    visit_date = datetime.now().strftime("%Y-%m-%d")

    # Print the details for debugging
    print(f"Browser: {browser}, OS: {os}, Device: {device_type}")
    print(f"IP: {user_ip}, City: {city}, Country: {country}")
    print(f"Visit Time: {visit_time}, Visit Date: {visit_date}")

    # Log the data 
    analytics_data.log_request_data(
        user_agent=user_agent,
        ip_address=user_ip,
        session_id=session_id,
        timestamp=datetime.now(),
        browser=browser,
        os=os,
        device_type=device_type,
        city=city,
        country=country,
        visit_time=visit_time,
        visit_date=visit_date
    )

    return render_template('index.html', page_title="Welcome")



@app.route('/search', methods=['GET', 'POST'])
def search_form_post():
    if request.method == 'POST':
        search_query = request.form['search-query']
        session['last_search_query'] = search_query
        search_id = analytics_data.save_query_terms(search_query)
        timestamp = datetime.now()
        
        # Log search query data
        session_id = session.get('session_id')  # Retrieve the session_id
        analytics_data.log_query(search_query, session_id, timestamp)

        results = search_engine.search(search_query, search_id, corpus)
        found_count = len(results)
        session['last_found_count'] = found_count

        # Save the results page URL in the session
        session['last_search_url'] = url_for('search_form_post', _external=True)  # Store the full URL for results page
        
        # Store the search results and their ranks in the session
        session['search_results'] = [result.to_json() for result in results]  # Save results in session
        print("search_results:", session['search_results'])
        return render_template('results.html', results_list=results, page_title="Results", found_counter=found_count)

    elif request.method == 'GET':
        results = session.get('search_results', [])
        found_count = len(results)
        return render_template('results.html', results_list=results, page_title="Results", found_counter=found_count)


@app.route('/doc_details', methods=['GET'])
def doc_details():
    clicked_doc_id = request.args.get("id")
    print("click in id={}".format(clicked_doc_id))
    
    session_id = session['session_id']
    click_timestamp = datetime.now(timezone.utc)

    
    # Retrieve rank of clicked document
    stored_results = session.get('search_results', [])
    clicked_doc_rank = None
    for result in stored_results:
        if str(result['id']) == clicked_doc_id:
            clicked_doc_rank = result['ranking']
            break
    
    analytics_data.log_click(clicked_doc_id, session_id, clicked_doc_rank)


    # Log dwell time
    last_timestamp = session.get('last_click_timestamp', click_timestamp)
    if isinstance(last_timestamp, str):
        # Convert stored string to a timezone-aware datetime
        last_timestamp = datetime.fromisoformat(last_timestamp).astimezone(timezone.utc)

    dwell_time = (click_timestamp - last_timestamp).total_seconds()
    analytics_data.log_dwell_time(clicked_doc_id, session_id, dwell_time)

    session['last_click_timestamp'] = click_timestamp
    doc = corpus[int(clicked_doc_id)]
    
    # # store data in statistics table 1
    # if clicked_doc_id in analytics_data.fact_clicks.keys():
    #     analytics_data.fact_clicks[clicked_doc_id] += 1
    # else:
    #     analytics_data.fact_clicks[clicked_doc_id] = 1

    print("fact_clicks count for id={} is {}".format(clicked_doc_id, analytics_data.fact_clicks[clicked_doc_id]))


    return render_template('doc_details.html', doc=doc)



@app.route('/stats', methods=['GET'])
def stats():
    """
    Show statistics for clicked documents with customizable sorting.
    """
    # Get the sorting criterion from query parameters (default to "count")
    sort_by = request.args.get('sort_by', 'count')  # Options: "count", "total_dwell", "average_dwell"

    dwell_time_stats = analytics_data.get_dwell_time_statistics()
    docs = []

    for doc_id in analytics_data.fact_clicks:
        row: Document = corpus[int(doc_id)]
        count = analytics_data.fact_clicks[doc_id]['count']
        dwell_time = dwell_time_stats.get(doc_id, {"average": 0, "total": 0, "count": 0})

        doc = StatsDocument(
            id=row.id,
            title=row.title,
            description=row.description,
            date=row.date,
            url=row.url,
            count=count,
            dwell_time=dwell_time
        )
        docs.append(doc)

    # Sort based on the chosen criterion
    if sort_by == 'total_dwell':
        docs.sort(key=lambda d: d.dwell_time['total'], reverse=True)
    elif sort_by == 'average_dwell':
        docs.sort(key=lambda d: d.dwell_time['average'], reverse=True)
    else:  # Default to "count"
        docs.sort(key=lambda d: d.count, reverse=True)

    return render_template('stats.html', clicks_data=docs, sort_by=sort_by)


@app.route('/dashboard', methods=['GET'])
def dashboard():
    # Visited documents
    visited_docs = []
    for doc_id, data in analytics_data.fact_clicks.items():
        d = corpus[int(doc_id)]
        doc = ClickedDoc(doc_id, d.description, data['count'])
        visited_docs.append(doc)

    # Sort visited documents by click count
    visited_docs.sort(key=lambda doc: doc.counter, reverse=True)

    # Serialize visited_docs for rendering in the template
    serialized_docs = [doc.to_json() for doc in visited_docs]

    # Browser statistics
    browser_data = analytics_data.get_browser_statistics()
    print(browser_data)

    # Query statistics
    query_data = analytics_data.get_query_statistics()

    # Location statistics (city and country distribution)
    city_data = {}
    country_data = {}
    for request in analytics_data.fact_requests:
        city = request.get('city', 'Unknown')
        country = request.get('country', 'Unknown')
        city_data[city] = city_data.get(city, 0) + 1
        country_data[country] = country_data.get(country, 0) + 1

    # Average rank of clicked documents
    rank_data = {}
    for doc_id, data in analytics_data.fact_clicks.items():
        if 'ranks' in data and data['ranks']:
            rank_data[doc_id] = sum(data['ranks']) / len(data['ranks'])
            
        # Rank distribution (frequency of clicked ranks)
    rank_distribution = {}
    for doc_id, rank in rank_data.items():
        rounded_rank = round(rank,2)  # Example: Round rank to nearest integer
        rank_distribution[rounded_rank] = rank_distribution.get(rounded_rank, 0) + 1
        
    # Get the location statistics
    location_data = analytics_data.location_stats

    # Render the dashboard template with all data
    return render_template(
        'dashboard.html',
        visited_docs=serialized_docs,
        browser_data=browser_data,
        query_data=query_data,
        location_data=location_data,
        rank_data=rank_data,
        rank_distribution=rank_distribution 
    )



@app.route('/sentiment')
def sentiment_form():
    return render_template('sentiment.html')


@app.route('/sentiment', methods=['POST'])
def sentiment_form_post():
    text = request.form['text']
    nltk.download('vader_lexicon')
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()
    score = ((sid.polarity_scores(str(text)))['compound'])
    return render_template('sentiment.html', score=score)


if __name__ == "__main__":
    app.run(port=8088, host="0.0.0.0", threaded=False, debug=True)
