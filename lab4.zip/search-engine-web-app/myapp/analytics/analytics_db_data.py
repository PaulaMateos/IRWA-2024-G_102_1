from myapp.data_model.models import db, Session, Click, Query, DwellTime
from datetime import datetime
import json
import random


class AnalyticsData:
    def __init__(self):
        pass

    def log_request_data(self, user_agent, ip_address, session_id, timestamp, browser, os, device_type, city, country, visit_time, visit_date):
        """Log HTTP request and user context details into the database."""
        session = Session(
            session_id=session_id,
            user_agent=user_agent,
            ip_address=ip_address,
            city=city,
            country=country,
            timestamp=timestamp,
            browser=browser,
            os=os,
            device_type=device_type,
            visit_time=visit_time,
            visit_date=visit_date
        )
        db.session.add(session)
        db.session.commit()

    def log_click(self, doc_id, session_id, clicked_doc_rank=None):
        """Log clicks on a document with rank information into the database."""
        click = Click(
            doc_id=doc_id,
            session_id=session_id,
            timestamp=datetime.now(),
            rank=clicked_doc_rank
        )
        db.session.add(click)
        db.session.commit()

    def log_query(self, query, session_id, timestamp):
        """Log search queries with metadata into the database."""
        query_obj = Query(
            query_text=query,
            session_id=session_id,
            timestamp=timestamp,
            term_count=len(query.split())  # Count the number of terms in the query
        )
        db.session.add(query_obj)
        db.session.commit()

    def log_dwell_time(self, doc_id, session_id, dwell_time):
        """Log the dwell time for a document into the database."""
        dwell_time_obj = DwellTime(
            doc_id=doc_id,
            session_id=session_id,
            dwell_time=dwell_time,
            timestamp=datetime.now()
        )
        db.session.add(dwell_time_obj)
        db.session.commit()

    def get_browser_statistics(self):
        """Get browser statistics from the database."""
        # You can query the database to get the browser statistics or you can collect this during logging
        return {}  # Placeholder for your implementation

    def get_query_statistics(self):
        """Get query statistics from the database."""
        query_freq = {}
        queries = Query.query.all()
        for query in queries:
            query_freq[query.query_text] = query_freq.get(query.query_text, 0) + 1
        return query_freq
    
    def save_query_terms(self, terms: str) -> int:
        print(self)
        return random.randint(0, 100000)

class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
