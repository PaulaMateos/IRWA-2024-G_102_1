import json
import random


class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


import time
from datetime import datetime

class AnalyticsData:
    def __init__(self):
        self.fact_requests = []  # HTTP request logs
        self.fact_clicks = {}    # Document clicks {doc_id: count}
        self.fact_queries = []   # Search queries with metadata
        self.sessions = {}       # Sessions data {session_id: session_info}
        self.dwell_times = {}    # Dwell times {doc_id: [times]}
        self.browser_stats = {}  # Browsers usage count
        self.location_stats = {} 

    def log_request_data(self, user_agent, ip_address, session_id, timestamp, browser=None, os=None, device_type=None, city=None, country=None, visit_time=None, visit_date=None):
        """Log HTTP request and user context details."""
        request_info = {
            'user_agent': user_agent,
            'ip_address': ip_address,
            'session_id': session_id,
            'timestamp': timestamp,
            'browser': browser,
            'os': os,
            'device_type': device_type,
            'city': city,
            'country': country,
            'visit_time': visit_time,
            'visit_date': visit_date
        }
        self.fact_requests.append(request_info)
        
        # Track city and country statistics
        location_key = f"{city}, {country}"
        if location_key not in self.location_stats:
            self.location_stats[location_key] = 0
        self.location_stats[location_key] += 1
        
        # Update browser statistics
        if browser:
            self.browser_stats[browser] = self.browser_stats.get(browser, 0) + 1


    
    # def log_request_data(self, user_agent, ip_address, session_id, timestamp):
    #     """Log HTTP request details."""
    #     request_info = {
    #         'user_agent': user_agent,
    #         'ip_address': ip_address,
    #         'session_id': session_id,
    #         'timestamp': timestamp
    #     }
    #     self.fact_requests.append(request_info)
        
    #     # Update browser statistics
    #     browser = httpagentparser.detect(user_agent).get('browser', {}).get('name', 'Unknown')
    #     if browser:
    #         self.browser_stats[browser] = self.browser_stats.get(browser, 0) + 1

    def log_click(self, doc_id, session_id, clicked_doc_rank=None):
        """Log clicks on a document with rank information."""
        if doc_id not in self.fact_clicks:
            self.fact_clicks[doc_id] = {'count': 0, 'ranks': []}

        # Increment click count
        self.fact_clicks[doc_id]['count'] += 1

        # Track rank of clicked document
        if clicked_doc_rank is not None:
            self.fact_clicks[doc_id]['ranks'].append(clicked_doc_rank)

        # Ensure session data is initialized
        if session_id not in self.sessions:
            self.sessions[session_id] = {'queries': [], 'clicks': []}

        # Add document click to session
        self.sessions[session_id]['clicks'].append({'doc_id': doc_id, 'rank': clicked_doc_rank})


    def log_query(self, query, session_id, timestamp):
        """Log search queries with metadata."""
        query_terms = query.split()
        query_info = {
            'query': query,
            'term_count': len(query_terms),
            'term_order': query_terms,
            'timestamp': timestamp,
            'session_id': session_id
        }
        self.fact_queries.append(query_info)
        if session_id not in self.sessions:
            self.sessions[session_id] = {'queries': [], 'clicks': []}
        self.sessions[session_id]['queries'].append(query_info)

    def log_dwell_time(self, doc_id, session_id, dwell_time):
        """Log the dwell time for a document."""
        if doc_id not in self.dwell_times:
            self.dwell_times[doc_id] = []
        self.dwell_times[doc_id].append(dwell_time)
        if session_id in self.sessions:
            self.sessions[session_id].setdefault('dwell_times', {})[doc_id] = dwell_time

    def get_browser_statistics(self):
        """Get browser statistics from the database."""
 
        return self.browser_stats


    def get_query_statistics(self):
        """Get query statistics."""
        query_freq = {}
        for query in self.fact_queries:
            query_freq[query['query']] = query_freq.get(query['query'], 0) + 1
        return query_freq
    
    def get_dwell_time_statistics(self):
        """Compute average and total dwell time for each document."""
        dwell_time_stats = {}
        for doc_id, times in self.dwell_times.items():
            avg_time = sum(times) / len(times) if times else 0
            total_time = sum(times)
            dwell_time_stats[doc_id] = {
                'average': avg_time,
                'total': total_time,
                'count': len(times)
            }
        return dwell_time_stats
        # statistics table 1
    # fact_clicks is a dictionary with the click counters: key = doc id | value = click counter
    #fact_clicks = dict([])

    # statistics table 2
    fact_two = dict([])

    # statistics table 3
    fact_three = dict([])

        
    def save_query_terms(self, terms: str) -> int:
        print(self)
        return random.randint(0, 100000)