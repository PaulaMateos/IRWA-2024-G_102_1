import json


class Document:
    """
    Original corpus data as an object
    """

    def __init__(self, id, title, description, date, likes, retweets, url, hashtags):
        self.id = id
        self.title = title
        self.description = description
        self.date = date
        self.likes = likes
        self.retweets = retweets
        self.url = url
        self.hashtags = hashtags

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


class StatsDocument:
    """
    Original corpus data as an object
    """

    def __init__(self, id, title, description, date, url, count, dwell_time=None):
        self.id = id
        self.title = title
        self.description = description
        self.date = date
        self.url = url
        self.count = count
        # Dwell time statistics
        self.dwell_time = dwell_time or {"average": 0, "total": 0, "count": 0}

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
    
    def get_dwell_time_statistics(self):
        """Compute average and total dwell time for each document."""
        dwell_time_stats = {}
        for doc_id, times in self.dwell_times.items():
            avg_time = sum(times) / len(times) if times else 0
            total_time = sum(times)
            dwell_time_stats[doc_id] = {
                'average': avg_time,
                'total': total_time,
                'count': len(times)
            }
        return dwell_time_stats



class ResultItem:
    def __init__(self, id, title, description, date, url, ranking):
        self.id = id
        self.title = title
        self.description = description
        self.date = date
        self.url = url
        self.ranking = ranking
        
    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
