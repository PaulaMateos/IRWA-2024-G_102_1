import datetime
import math
import random
from collections import Counter

from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import create_inverted_index, preprocess_tweet, query_inverted_index, search_in_corpus

def build_search_results(corpus: dict, search_id: str, query: str):
    """
    Builds a list of search results ranked using TF-IDF.
    :param corpus: A dictionary of documents.
    :param search_id: Unique search ID for tracking.
    :param query: Search query string.
    :return: A list of ranked ResultItem objects.
    """
    from myapp.search.algorithms import preprocess_tweet

    # Step 1: Preprocess the query
    query_terms = preprocess_tweet(query)
    print("Query terms:", query_terms)

    # Step 2: Build the inverted index
    inverted_index = create_inverted_index(corpus)
    total_docs = len(corpus)

    # Step 3: Calculate IDF for each term in the query
    idf = {}
    for term in query_terms:
        doc_freq = len(inverted_index.get(term, []))
        idf[term] = math.log(total_docs / (1 + doc_freq))  # Smoothing with +1 to avoid division by zero

    # Step 4: Score each document using TF-IDF
    doc_scores = Counter()
    for term in query_terms:
        if term in inverted_index:
            for doc_id, term_freq in inverted_index[term]:
                doc_scores[doc_id] += term_freq * idf[term]

    # Step 5: Normalize scores (optional)
    max_score = max(doc_scores.values(), default=1)
    for doc_id in doc_scores:
        doc_scores[doc_id] /= max_score

    # Step 6: Build ResultItem objects
    results = []
    for doc_id, score in doc_scores.most_common():
        doc = corpus[doc_id]
        results.append(
            ResultItem(
                doc.id,
                doc.title,
                doc.description,
                doc.date,
                f"doc_details?id={doc.id}&search_id={search_id}&param2=2",
                score,
            )
        )

    return results

def build_demo_results(corpus: dict, search_id):
    """
    Helper method, just to demo the app
    :return: a list of demo docs sorted by ranking
    """
    res = []
    size = len(corpus)
    ll = list(corpus.values())
    for index in range(random.randint(0, 40)):
        item: Document = ll[random.randint(0, size - 1)]
        res.append(ResultItem(item.id, item.title, item.description, item.date,
                              "doc_details?id={}&search_id={}&param2=2".format(item.id, search_id), random.random()))

    # for index, item in enumerate(corpus['Id']):
    #     # DF columns: 'Id' 'Tweet' 'Username' 'Date' 'Hashtags' 'Likes' 'Retweets' 'Url' 'Language'
    #     res.append(DocumentInfo(item.Id, item.Tweet, item.Tweet, item.Date,
    #                             "doc_details?id={}&search_id={}&param2=2".format(item.Id, search_id), random.random()))

    # simulate sort by ranking
    res.sort(key=lambda doc: doc.ranking, reverse=True)
    return res


class SearchEngine:
    """educational search engine"""

    def search(self, search_query, search_id, corpus):
        print("Search query:", search_query)

        results = []
        ##### your code here #####
        # results = build_search_results(corpus, search_id, search_query)  # replace with call to search algorithm
        inverted_index = create_inverted_index(corpus)
        # results = query_inverted_index(search_query, inverted_index, corpus)
        results = search_in_corpus(inverted_index, search_query, corpus)
        ##### your code here #####

        return results
