import re
import pandas as pd

from myapp.core.utils import load_json_file
from myapp.search.objects import Document

import json
from typing import List

_corpus = {}


def load_corpus(path) -> [Document]:
    """
    Load file and transform to dictionary with each document as an object for easier treatment when needed for displaying
     in results, stats, etc.
    :param path:
    :return:
    """
    df = custom_load_corpus(path)

    df.apply(_row_to_doc_dict, axis=1)
    return _corpus

import json
from typing import List

# Function to load corpus and extract relevant fields
def custom_load_corpus(path: str) -> pd.DataFrame:
    documents = []
    with open(path, 'r') as file:
        for line in file:
            # Load the JSON from each line
            document_data = json.loads(line)
            
            # Extract the necessary fields from the document
            id = document_data.get('id', None)
            title = document_data.get('title', None)
            description = document_data.get('content', '')
            date = document_data.get('date', None)
            likes = document_data.get('likeCount', 0)
            retweets = document_data.get('retweetCount', 0)
            url = document_data.get('url', '')
            username = document_data.get('user', {}).get('username', '')
            
            # Extract hashtags from the description
            hashtags = extract_hashtags(description)
            
            # Create the Document object
            document = Document(id=id, title=title, description=description, date=date, 
                                likes=likes, retweets=retweets, url=url, hashtags=hashtags)
            
            # Append the Document object to the list
            documents.append(document)
            
    # Convert documents to a DataFrame (optional, if needed)
    data = [{
        'id': doc.id, 'title': doc.title, 'description': doc.description, 'date': doc.date,
        'likes': doc.likes, 'retweets': doc.retweets, 'url': doc.url, 'hashtags': doc.hashtags
    } for doc in documents]
    
    df = pd.DataFrame(data)

    df.columns = [col.capitalize() for col in df.columns]


    return df

# function to extract hashtags
def extract_hashtags(row):
    hashtags = []
    hashtags = re.findall(r"#(\w+)", row)        
    return hashtags
    

def _load_corpus_as_dataframe(path):
    """
    Load documents corpus from file in 'path'
    :return:
    """
    json_data = load_json_file(path)
    tweets_df = pd.DataFrame([json_data])
    tweets_df.drop(tweets_df.columns[0], axis=1, inplace=True)
    _clean_hashtags_and_urls(tweets_df)
    # Rename columns to obtain: Tweet | Username | Date | Hashtags | Likes | Retweets | Url | Language
    corpus = tweets_df.rename(
        columns={"url":"Url","id": "Id", "content": "Description", "user": "Username", "date": "Date", # Description <-- Tweet
                 "likeCount": "Likes", "title": "Title",
                 "retweetCount": "Retweets", "lang": "Language", "hashtags": "Hashtags"})

    # select only interesting columns
    filter_columns = ["Id", "Description", "Username", "Date", "Hashtags", "Likes", "Retweets", "Url", "Language"]
    corpus = corpus[filter_columns]
    print("Len corpus-------------------------------->", len(corpus))
    return corpus


def _build_tags(row):
    tags = []
    tags = re.findall(r"#(\w+)", row)        
    return tags


def _build_url(row):
    url = ""
    try:
        url = row["entities"]["url"]["urls"][0]["url"]  # tweet URL
    except:
        try:
            url = row["retweeted_status"]["extended_tweet"]["entities"]["media"][0]["url"]  # Retweeted
        except:
            url = ""
    return url


def _clean_hashtags_and_urls(df):
    df["hashtags"] = df["content"].apply(_build_tags)
    df["Url"] = df.apply(lambda row: _build_url(row), axis=1)
    # df["Url"] = "TODO: get url from json"


def load_tweets_as_dataframe3(json_data):
    """Load json data into a dataframe

    Parameters:
    json_data (string): the json object

    Returns:
    DataFrame: a Panda DataFrame containing the tweet content in columns
    """

    # Load the JSON object into a DataFrame.
    dataframe = pd.DataFrame(json_data).transpose()
    print(dataframe)
    # select only interesting columns
    filter_columns = ["id", "full_text", "created_at", "entities", "retweet_count", "favorite_count", "lang"]
    dataframe = dataframe[filter_columns]
    return dataframe


def _row_to_doc_dict(row: pd.Series):
    """
    Convert a DataFrame row into a Document object and store it in the global _corpus dictionary.
    :param row: A single row of the DataFrame
    """
    _corpus[row['Id']] = Document(
        row['Id'], row['Description'][:100], row['Description'], row['Date'], row['Likes'],
        row['Retweets'], row['Url'], row['Hashtags']
    )

