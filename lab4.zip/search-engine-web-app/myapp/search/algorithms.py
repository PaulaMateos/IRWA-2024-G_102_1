import math
from collections import defaultdict, Counter
import datetime
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from myapp.search.objects import ResultItem
# import nltk
# nltk.download('stopwords')

def search_in_corpus(inverted_index, query, corpus):
    """
    Ranks documents based on TF-IDF relevance to a query.

    Arguments:
    inverted_index -- the inverted index with terms as keys and lists of (doc_id, term_freq) as values.
    query -- the user query to match against documents.
    corpus -- dictionary with doc_id as keys and Document objects as values.

    Returns:
    ranked_docs -- list of ResultItem objects, ranked by TF-IDF.
    """
    num_documents = len(corpus)
    ranked_docs = defaultdict(float)

    # Preprocess the query
    query_terms = preprocess_tweet(query).split()

    # Calculate TF-IDF scores for each term in the query
    for term in query_terms:
        if term in inverted_index:
            df = len(inverted_index[term])  # Document Frequency (DF)
            idf = math.log(num_documents / (1 + df), 2)  # Inverse Document Frequency (IDF)

            for doc_id, term_freq in inverted_index[term]:
                tf = term_freq / len(preprocess_tweet(corpus[doc_id].description + " " + corpus[doc_id].title).split())
                tf_idf_score = tf * idf
                ranked_docs[doc_id] += tf_idf_score  # Accumulate scores

    # Sort documents by TF-IDF score
    sorted_docs = sorted(ranked_docs.items(), key=lambda item: item[1], reverse=True)

    # Build a list of ResultItem objects
    result_items = [
        ResultItem(
            id=doc_id,
            title=corpus[doc_id].title,
            description=corpus[doc_id].description,
            date=corpus[doc_id].date,
            url=f"doc_details?id={doc_id}&search_id=1",
            ranking=score,
        )
        for doc_id, score in sorted_docs
    ]

    # Limit the number of results to 10
    result_items = result_items[:10]

    return result_items


def preprocess_tweet(tweet_content):
    stop_words = set(stopwords.words('english'))
    ps = PorterStemmer()

    # Lowercase the tweet
    tweet_content = tweet_content.lower()
    tokenized_tweet = tweet_content.split()

    # Remove stop words and punctuation, apply stemming
    processed_tokens = [ps.stem(word) for word in tokenized_tweet if word.isalpha() and word not in stop_words]

    # Return the processed text as a string
    return ' '.join(processed_tokens)

def create_inverted_index(corpus):
    """
    Builds an inverted index from the corpus.
    :param corpus: Dictionary of Document objects.
    :return: Inverted index mapping terms to [(doc_id, term_freq)].
    """
    from collections import defaultdict, Counter

    index = defaultdict(list)

    for doc_id, doc in corpus.items():
        # Concatenate description and title, preprocess, and tokenize into terms
        content = doc.description + " " + doc.title
        terms = preprocess_tweet(content).split()
        term_freq = Counter(terms)

        for term, freq in term_freq.items():
            index[term].append((doc_id, freq))  # Append doc_id and term frequency

    return index



def query_inverted_index(query, inverted_index, corpus):
    query = preprocess_tweet(query)
    terms = query.split()
    print(f"Processed query terms: {terms}")  # Debugging

    if not terms:
        return []

    result_doc_ids = set(inverted_index.get(terms[0], []))
    for term in terms[1:]:
        result_doc_ids &= set(inverted_index.get(term, []))

    result_docs = [corpus[doc_id] for doc_id in result_doc_ids if doc_id in corpus]
    return result_docs

