from flask_sqlalchemy import SQLAlchemy

# Initialize SQLAlchemy
db = SQLAlchemy()

# Session model to store session data
class Session(db.Model):
    __tablename__ = 'sessions'
    session_id = db.Column(db.String(100), primary_key=True)
    user_agent = db.Column(db.String(200))
    ip_address = db.Column(db.String(50))
    city = db.Column(db.String(100))
    country = db.Column(db.String(100))
    timestamp = db.Column(db.DateTime)
    browser = db.Column(db.String(50))
    os = db.Column(db.String(50))
    device_type = db.Column(db.String(50))
    visit_time = db.Column(db.String(50))
    visit_date = db.Column(db.String(50))

    def __init__(self, session_id, user_agent, ip_address, city, country, timestamp, browser, os, device_type, visit_time, visit_date):
        self.session_id = session_id
        self.user_agent = user_agent
        self.ip_address = ip_address
        self.city = city
        self.country = country
        self.timestamp = timestamp
        self.browser = browser
        self.os = os
        self.device_type = device_type
        self.visit_time = visit_time
        self.visit_date = visit_date

    def __repr__(self):
        return f"<Session {self.session_id}>"

# Click model to store clicked documents
class Click(db.Model):
    __tablename__ = 'clicks'
    click_id = db.Column(db.Integer, primary_key=True)
    doc_id = db.Column(db.String(100))
    session_id = db.Column(db.String(100), db.ForeignKey('sessions.session_id'))
    timestamp = db.Column(db.DateTime)
    rank = db.Column(db.Float)

    def __init__(self, doc_id, session_id, timestamp, rank=None):
        self.doc_id = doc_id
        self.session_id = session_id
        self.timestamp = timestamp
        self.rank = rank

    def __repr__(self):
        return f"<Click {self.click_id}, Doc {self.doc_id}>"

# Query model to store search queries
class Query(db.Model):
    __tablename__ = 'queries'
    query_id = db.Column(db.Integer, primary_key=True)
    query_text = db.Column(db.String(200))
    session_id = db.Column(db.String(100), db.ForeignKey('sessions.session_id'))
    timestamp = db.Column(db.DateTime)
    term_count = db.Column(db.Integer)

    def __init__(self, query_text, session_id, timestamp, term_count):
        self.query_text = query_text
        self.session_id = session_id
        self.timestamp = timestamp
        self.term_count = term_count

    def __repr__(self):
        return f"<Query {self.query_text}>"

# DwellTime model to store the dwell times for documents
class DwellTime(db.Model):
    __tablename__ = 'dwell_times'
    dwell_time_id = db.Column(db.Integer, primary_key=True)
    doc_id = db.Column(db.String(100))
    session_id = db.Column(db.String(100), db.ForeignKey('sessions.session_id'))
    dwell_time = db.Column(db.Float)
    timestamp = db.Column(db.DateTime)

    def __init__(self, doc_id, session_id, dwell_time, timestamp):
        self.doc_id = doc_id
        self.session_id = session_id
        self.dwell_time = dwell_time
        self.timestamp = timestamp

    def __repr__(self):
        return f"<DwellTime {self.dwell_time_id}, Doc {self.doc_id}>"
