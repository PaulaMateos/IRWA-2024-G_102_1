import datetime
import math
import random
from collections import Counter

from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import create_inverted_index, preprocess_tweet

def build_search_results(corpus: dict, search_id: str, query: str):
    """
    Builds a list of search results with an enhanced ranking system using TF-IDF.
    :param corpus: A dictionary of documents.
    :param search_id: Unique search ID for tracking.
    :param query: Search query string.
    :return: A list of ranked ResultItem objects.
    """
    res = []
    query_terms = query.lower().split()
    current_date = datetime.datetime.now()

    # Step 1: Create an inverted index
    inverted_index = create_inverted_index(corpus)

    # Step 2: Calculate IDF for each term in the query
    num_documents = len(corpus)
    term_idf = {}
    for term in query_terms:
        if term in inverted_index:
            df = len(inverted_index[term])  # Document Frequency (DF)
            idf = math.log(num_documents / (1 + df), 2)  # Inverse Document Frequency (IDF)
            term_idf[term] = idf

    # Step 3: For each document, calculate the TF-IDF score
    for doc_id, document in corpus.items():
        # Initialize ranking components
        tfidf_score = 0
        recency_score = 0
        length_penalty = 0

        # Preprocess document description (tokenization, stopword removal, etc.)
        document_content = preprocess_tweet(document.description).split()
        term_count = Counter(document_content)

        # Relevance: Calculate TF-IDF for the query terms in the document
        for term in query_terms:
            if term in term_idf:  # Only consider terms in the query
                tf = term_count[term] / len(document_content)  # Term Frequency (TF)
                idf = term_idf[term]  # Inverse Document Frequency (IDF)
                tfidf_score += tf * idf  # Add TF-IDF score to the document's relevance score

        # Debugging: Check if the TF-IDF score is being calculated correctly
        print(f"Document ID: {document.id}, TF-IDF Score: {tfidf_score:.4f}")

        # Recency: Recent documents are favored
        try:
            doc_date = datetime.datetime.strptime(document.doc_date, "%Y-%m-%d")
            days_since_creation = (current_date - doc_date).days
            recency_score = 1 / math.sqrt(days_since_creation + 1)  # Penalize older docs logarithmically
        except ValueError:
            recency_score = 0  # Assign default score if date is invalid

        # Length Penalty: Penalize excessively long descriptions
        if document.description:
            length_penalty = min(len(document.description) / 1000, 1)  # Scale between 0 and 1

        # Popularity/Engagement (if applicable): Simulate with a random value
        popularity_score = random.uniform(0, 1)

        # Combine scores into a ranking score
        ranking_score = (
            tfidf_score * 0.6 +
            recency_score * 0.3 +
            popularity_score * 0.2 -
            length_penalty * 0.1  # Penalize lengthy descriptions slightly
        )

        # Debugging: Check the final ranking score for the document
        print(f"Document ID: {document.id}, Final Ranking Score: {ranking_score:.4f}")

        # Add the document if it has a non-zero ranking score
        if ranking_score > 0:
            res.append(ResultItem(
                document.id,
                document.title,
                document.description,
                document.doc_date,
                f"doc_details?id={document.id}&search_id={search_id}&param2=2",
                ranking_score
            ))

    # Step 4: Sort results by ranking score in descending order
    res.sort(key=lambda doc: doc.ranking, reverse=True)

    # Print the top 10 ranked results
    print("Top 10 Ranked Results:")
    for i, result in enumerate(res[:10]):
        print(f"Rank {i+1}: {result.title} (Score: {result.ranking:.4f})")
        print(f"URL: {result.url}")
        print(f"Description: {result.description[:150]}...")  # Print the first 150 characters of description
        print("-" * 50)

    return res



def build_demo_results(corpus: dict, search_id):
    """
    Helper method, just to demo the app
    :return: a list of demo docs sorted by ranking
    """
    res = []
    size = len(corpus)
    ll = list(corpus.values())
    for index in range(random.randint(0, 40)):
        item: Document = ll[random.randint(0, size - 1)]
        res.append(ResultItem(item.id, item.title, item.description, item.doc_date,
                              "doc_details?id={}&search_id={}&param2=2".format(item.id, search_id), random.random()))

    # for index, item in enumerate(corpus['Id']):
    #     # DF columns: 'Id' 'Tweet' 'Username' 'Date' 'Hashtags' 'Likes' 'Retweets' 'Url' 'Language'
    #     res.append(DocumentInfo(item.Id, item.Tweet, item.Tweet, item.Date,
    #                             "doc_details?id={}&search_id={}&param2=2".format(item.Id, search_id), random.random()))

    # simulate sort by ranking
    res.sort(key=lambda doc: doc.ranking, reverse=True)
    return res


class SearchEngine:
    """educational search engine"""

    def search(self, search_query, search_id, corpus):
        print("Search query:", search_query)

        results = []
        ##### your code here #####
        # results = build_search_results(corpus, search_id, search_query)  # replace with call to search algorithm
        # inverted_index = create_inverted_index(corpus)
        results = build_search_results(corpus, search_id, search_query)

        # results = search_in_corpus(search_query)
        ##### your code here #####

        return results
