import math
from collections import defaultdict, Counter
import datetime

def search_in_corpus(query):
    # 1. create create_tfidf_index

    # 2. apply ranking
    return ""

def preprocess_tweet(query):
    # Placeholder preprocessing function (implement based on actual preprocessing steps)
    return query.lower()

def create_inverted_index(corpus: dict):
    """
    Create an inverted index from the corpus.
    :param corpus: A dictionary of documents.
    :return: An inverted index (dictionary of term to document list).
    """
    inverted_index = defaultdict(list)

    for doc_id, document in corpus.items():
        # Assuming 'description' is the correct attribute
        terms = preprocess_tweet(document.description).split()

        for term in terms:
            inverted_index[term].append(doc_id)

    return inverted_index


def create_index_tfidf(inverted_index, query, processed_tweets):
    """
    Ranks documents based on TF-IDF relevance to a query with added ranking factors such as recency and length.

    Arguments:
    inverted_index -- the inverted index with terms as keys and lists of doc_ids as values.
    query -- the user query to match against documents.
    processed_tweets -- dictionary with docId as keys and processed tweet content as values.

    Returns:
    ranked_docs -- dictionary of doc_ids and their relevance scores, ranked by TF-IDF and adjusted by recency and length.
    """
    num_documents = len(processed_tweets)
    ranked_docs = defaultdict(float)

    # Preprocess the query
    query_terms = preprocess_tweet(query).split()

    # Calculate DF, IDF, and TF on-the-fly
    for term in query_terms:
        if term in inverted_index:
            df = len(inverted_index[term])  # Document Frequency (DF)
            idf = math.log(num_documents / (1 + df), 2)  # Inverse Document Frequency (IDF)

            for doc_id in inverted_index[term]:
                document_content = processed_tweets[doc_id]
                terms_in_doc = document_content.split()
                term_count = Counter(terms_in_doc)
                tf = term_count[term] / len(terms_in_doc)  # Term Frequency (TF)

                tf_idf_score = tf * idf  # Calculate TF-IDF score
                ranked_docs[doc_id] += tf_idf_score  # Accumulate score for documents

    # After calculating TF-IDF scores, we need to adjust the ranking using additional factors
    adjusted_ranking = {}

    current_date = datetime.datetime.now()

    for doc_id, tfidf_score in ranked_docs.items():
        document_content = processed_tweets[doc_id]

        # Recency: Documents with more recent timestamps should be favored
        try:
            doc_date = datetime.datetime.strptime(document_content.split("\n")[0], "%Y-%m-%d")  # Assuming first line is date
            days_since_creation = (current_date - doc_date).days
            recency_score = 1 / math.sqrt(days_since_creation + 1)  # Penalize older docs logarithmically
        except ValueError:
            recency_score = 0  # Default score if the date is invalid or not found

        # Length penalty: Penalize excessively long descriptions to avoid over-weighting long documents
        length_penalty = min(len(document_content) / 1000, 1)  # Scale between 0 and 1

        # Adjust the final score by incorporating TF-IDF, recency, and length
        adjusted_score = tfidf_score * 0.6 + recency_score * 0.3 - length_penalty * 0.1

        # Store the adjusted score for ranking
        adjusted_ranking[doc_id] = adjusted_score

    # Sort documents by adjusted score (TF-IDF + recency + length) in descending order
    sorted_ranked_docs = dict(sorted(adjusted_ranking.items(), key=lambda item: item[1], reverse=True))

    return sorted_ranked_docs